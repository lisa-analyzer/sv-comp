These are adopted JayHorn's benchmarks. The original version can be found here:
    repo: https://github.com/jayhorn/cav_experiments.git
    branch: master
    root directory: benchmarks/recursive
The benchmarks were taken from the repo: 24 January 2018
The modification we made only adopts the benchmarks to the format of SV-COMP.

